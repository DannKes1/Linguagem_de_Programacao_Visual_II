﻿using Aula17_09_2025.Models.Livro;
using Microsoft.AspNetCore.Mvc;

namespace Aula17_09_2025.Controllers;

public class LivroController : Controller
{

    
    private List<Livro> ObterLivros()
    {
        return new List<Livro>()
        {
            new Livro {
                Id = 1, 
                Titulo = "1984",
                Autor = "George Orwell", 
                Ano = 1949,
                ISBN = "978-0451524935",
                Disponivel = false,
                DataCadastro = DateTime.Now,
            },
            new Livro {
                Id = 2, 
                Titulo = "O Sol é para Todos",
                Autor = "Harper Lee", 
                Ano = 1960,
                ISBN = "978-0061120084",
                Disponivel = true,
                DataCadastro = DateTime.Now,
            },
            new Livro {
                Id = 3, 
                Titulo = "Cem Anos de Solidão",
                Autor = "Gabriel García Márquez", 
                Ano = 1967,
                ISBN = "978-0060883287",
                Disponivel = true,
                DataCadastro = DateTime.Now,
            },
            new Livro {
                Id = 4, 
                Titulo = "O Grande Gatsby",
                Autor = "F. Scott Fitzgerald", 
                Ano = 1925,
                ISBN = "978-0743273565",
                Disponivel = true,
                DataCadastro = DateTime.Now,
            },
            new Livro {
                Id = 5, 
                Titulo = "Dom Quixote",
                Autor = "Miguel de Cervantes", 
                Ano = 1605,
                ISBN = "978-0060934347",
                Disponivel = true,
                DataCadastro = DateTime.Now,
            },
        };
    }

    private List<LivroViewModel> ObterTodosLivros()
    {
        var livros = ObterLivros();
        return livros.Select(l => LivroViewModel.FromLivro(l)).ToList();
    }

    private List<LivroViewModel> ObterLivrosFavoritos()
    {
        var livros = ObterLivros().Where(l => l.Id is 1 or 2 or 5).ToList();
        return livros.Select(l => LivroViewModel.FromLivro(l)).ToList();
    }
    
    // GET  
    public IActionResult Index()
    {
        var livros = ObterTodosLivros();
        return View(livros);
    }
    public IActionResult Favoritos()
    {
        var livros = ObterLivrosFavoritos();
        return View(livros);
    }

    
}