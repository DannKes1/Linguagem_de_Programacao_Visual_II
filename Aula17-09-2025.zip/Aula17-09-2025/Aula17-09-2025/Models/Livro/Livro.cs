﻿namespace Aula17_09_2025.Models.Livro;

public class Livro
{
    public int Id {get; set;}
    public string Titulo {get; set;} = string.Empty;
    public string Autor {get; set;} = string.Empty;
    public int Ano {get; set;}
    public string ISBN {get; set;} = string.Empty;
    public bool Disponivel { get; set; } = true;
    public DateTime DataCadastro {get; set;}
    }
    
    
    