﻿namespace Aula17_09_2025.Models.Livro;

public class LivroViewModel
{
    public int Id {get; set;}
    public string Titulo {get; set;} = string.Empty;
    public string Autor {get; set;} = string.Empty;
    public int Ano {get; set;}
    public bool Disponivel { get; set; } = true;


    public static LivroViewModel FromLivro(Livro livro)
    {
        return new LivroViewModel()
        {
            Id = livro.Id,
            Titulo = livro.Titulo,
            Autor = livro.Autor,
            Ano = livro.Ano,
            Disponivel = livro.Disponivel,
        };
    }
}
